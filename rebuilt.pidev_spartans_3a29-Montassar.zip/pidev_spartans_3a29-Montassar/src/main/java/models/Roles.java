package models;

public enum Roles {
    Proprietaire_de_Terrain,Joueur,Organisateur,Fournisseur;
}
